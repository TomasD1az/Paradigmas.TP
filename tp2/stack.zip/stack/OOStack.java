package stack;


public class OOStack {
	static public String stackEmptyErrorDescription = "Stack is empty";

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return true;
	}

	public OOStack push(String string) {
		// TODO Auto-generated method stub
		return this;
	}

	public Object pop() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object top() {
		// TODO Auto-generated method stub
		return null;
	}

	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

}
